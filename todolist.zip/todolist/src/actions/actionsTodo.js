
export const setTaskList = (tasklist)=>({
type:'ADD_TASK',
tasklist:tasklist
})