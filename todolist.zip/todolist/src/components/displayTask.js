import React, { PureComponent } from 'react';
import {connect} from 'react-redux';

class DisplayTask extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            
        }
    }

    render() {
        console.log(this.props.todoApp.tasklist)
        return (
            <div>
                {this.props.todoApp.tasklist !==null ||this.props.todoApp.tasklist ===undefined?
                    (this.props.todoApp.tasklist.map((todo,i)=>{
                        console.log(todo)
                        return(<div id="displayTask" className="displayTask">
                            <h>Title :{todo.title}</h>
                        <p>Description :{todo.description}</p>
                        <p>Status :{todo.status}</p>
                        {/* <button id="" */}
                    </div>)
                    })):''}
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        todoApp: state.todoApp
    }
}

export default connect(mapStateToProps,null)(DisplayTask)