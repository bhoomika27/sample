import React, { PureComponent } from 'react'
import './addList.css';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as actionsTodo from '../actions/actionsTodo'

class AddList extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            title:'',
            desc:'',
            status:'pending',
            today:null,
            dueDate:null,
            taskList:[],

        }
    }
    static getDerivedStateFromProps(props, state){
        console.log(React.version);
        return null;
      
        
    }
    componentDidMount(){
        if(this.state.dueDate===null){this.getDate();}

        console.log("My turn is second")
        
    }

    handleSubmit=(e)=>{

        e.preventDefault();
        
        const title = this.state.title;
        const description = this.state.desc;
        const status = this.state.status;
        const dueDate = this.state.dueDate;
        const taskObj = {title: title, description: description,status:status,dueDate:dueDate};
        const taskList = [...this.state.taskList, taskObj];
        console.log(taskList)
        this.setState({
            taskList: taskList
        });
        this.props.setTaskList(taskList);
        console.log("Hiiiiii Bhoomika going great")
    }

    handleInputValues =(e)=>{
        console.log(e.target.value,e.target.name)
        this.setState({[e.target.name]:e.target.value})
        
    }
    getDate=()=>{
        console.log(new Date().toJSON().split('T')[0])
        var today= new Date().toJSON().split('T')[0];
        console.log(today)
        this.setState({today:today})
        }
       

    render() {
        console.log(this.props.todoApp.tasklist)
        return (
            <div id="container">
                <form onSubmit={this.handleSubmit} > 
                <div className="titleDiv">
                <label className="titleLabel" >Title</label>
                <input type="text" id="title" name="title" className="title" placeholder="Enter Title" onChange={this.handleInputValues}></input>
                </div>
                <div className="descDiv">
                <label className="descLabel" htmlFor="description">Description</label>
                <textarea type="text" id="Description" name="desc" className="Description" placeholder="Enter Title" onChange={this.handleInputValues}></textarea>
                </div>
                <div className="statusDiv">
                <label className="titleLabel" htmlFor="business">Status</label>
                <select id="status" name="status" value={this.state.status} className="business" onChange={this.handleInputValues}>
                    <option value="pending">PENDING</option>
                    <option value="completed">COMPLETED</option>
                </select>
                </div>
                <div className="dueDayDiv">
                <label className="titleLabel" htmlFor="start">Title</label>
                <input type="date" id="dueDate" name="dueDate" className="dueDate" value={this.state.dueDate===null?this.state.today:this.state.dueDate} 
                    onChange={this.handleInputValues}  
                    min={this.state.today} />
                </div>
                <button type="submit" className="addBtn">ADD TASK</button>
                </form>
            </div>

        )
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        setTaskList:actionsTodo.setTaskList,
    },dispatch)
};
const mapStateToProps = (state) => {
    return {
        todoApp: state.todoApp
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(AddList);