import * as actionTypes from '../actions/actionsTodo'

const initialState = {
    tasklist:null,

  };


function todoApp(state = initialState, action) {
    console.log(action)
  switch (action.type) {
    case 'ADD_TASK':
        return state= setTodoList(state,action.tasklist);
    
    default:
      return state
  }
}

const setTodoList=(state,tasklist)=>{

  state={
    ...state,
    tasklist:tasklist
  }
return state
}

export default todoApp